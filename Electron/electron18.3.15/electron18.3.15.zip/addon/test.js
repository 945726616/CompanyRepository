const useDll = require('bindings')('useDll')
console.log(1231231)
console.log(useDll.add(1, 1))
console.log(useDll.base64())