const useDll = require('bindings')('useDll')

console.log(useDll.add(1, 1))