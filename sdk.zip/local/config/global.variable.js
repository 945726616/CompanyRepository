g_func = [];

g_version = "v6.6.1.1906101100";

g_browser = "";
g_appId = "";
g_isLog = false;
g_language = "en";
g_sdk_version = "";
g_time_zone = "";

msdk_agent = "";
g_user_name = "";
g_user_pass = "";

//var msdk_agent = "";
var g_server_https,g_server_http;
var g_server_device = "";
